import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { marked } from 'marked';
import { ChatService } from '../../services/chat.service';
import { Message } from '../../models/message';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
  ],
  template: `
    <div class="chat-container">
      <div class="messages" #messageContainer>
        <div *ngFor="let message of messages" class="message" [ngClass]="message.role">
          <mat-card>
            <mat-card-content>
              <div class="message-content" [innerHTML]="formatMessage(message.content)"></div>
              <div class="message-timestamp">{{ message.timestamp | date:'short' }}</div>
            </mat-card-content>
          </mat-card>
        </div>
      </div>
      
      <div class="input-container">
        <mat-form-field appearance="fill" class="message-input">
          <mat-label>Type your message...</mat-label>
          <input
            matInput
            [(ngModel)]="newMessage"
            (keyup.enter)="sendMessage()"
            placeholder="Type your message..."
          >
        </mat-form-field>
        <button
          mat-fab
          color="primary"
          (click)="sendMessage()"
          [disabled]="!newMessage.trim()"
        >
          <mat-icon>send</mat-icon>
        </button>
      </div>
    </div>
  `,
  styles: [`
    .chat-container {
      display: flex;
      flex-direction: column;
      height: 100vh;
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .messages {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      margin-bottom: 20px;
    }

    .message {
      margin-bottom: 20px;
      max-width: 80%;
    }

    .message.user {
      margin-left: auto;
      mat-card {
        background-color: #2196f3;
        color: white;
      }
    }

    .message.assistant {
      margin-right: auto;
      mat-card {
        background-color: #f5f5f5;
      }
    }

    .message-content {
      white-space: pre-wrap;
      padding: 10px;
    }

    .message-timestamp {
      font-size: 0.8em;
      opacity: 0.7;
      margin-top: 5px;
      text-align: right;
    }

    .input-container {
      display: flex;
      gap: 10px;
      align-items: center;
      padding: 20px;
      background-color: #fff;
      border-top: 1px solid #eee;
    }

    .message-input {
      flex: 1;
    }
  `]
})
export class ChatComponent {
  messages: Message[] = [];
  newMessage = '';

  constructor(private chatService: ChatService) {
    this.chatService.getMessages().subscribe(messages => {
      this.messages = messages;
      setTimeout(() => this.scrollToBottom());
    });
  }

  sendMessage(): void {
    if (this.newMessage.trim()) {
      this.chatService.sendMessage(this.newMessage);
      this.newMessage = '';
    }
  }

  formatMessage(content: string): string {
    return marked.parse(content, { async: false }) as string;
  }

  private scrollToBottom(): void {
    const messageContainer = document.querySelector('.messages');
    if (messageContainer) {
      messageContainer.scrollTop = messageContainer.scrollHeight;
    }
  }
}
