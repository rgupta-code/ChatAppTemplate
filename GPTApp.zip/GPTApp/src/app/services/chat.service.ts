import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private messages = new BehaviorSubject<Message[]>([]);

  constructor() {}

  getMessages(): Observable<Message[]> {
    return this.messages.asObservable();
  }

  // In a real application, this would make an API call to a backend service
  async sendMessage(content: string): Promise<void> {
    const userMessage: Message = {
      content,
      role: 'user',
      timestamp: new Date()
    };

    const currentMessages = this.messages.value;
    this.messages.next([...currentMessages, userMessage]);

    // Simulate AI response
    const aiMessage: Message = {
      content: 'This is a simulated response. In a real application, this would come from an AI API.',
      role: 'assistant',
      timestamp: new Date()
    };

    setTimeout(() => {
      this.messages.next([...this.messages.value, aiMessage]);
    }, 1000);
  }

  clearChat(): void {
    this.messages.next([]);
  }
}
